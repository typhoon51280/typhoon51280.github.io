from __future__ import unicode_literals, absolute_import
import mediasetinfinity.routes.root
import mediasetinfinity.routes.catalogo

__all__  = [
    "root",
    "catalogo",
]