from __future__ import unicode_literals, absolute_import
from mediasetinfinity.support import run
import mediasetinfinity.routes as routes # for route registering

__all__ = [
    "run",
    "routes",
]